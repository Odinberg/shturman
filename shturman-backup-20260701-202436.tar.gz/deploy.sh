#!/bin/bash
# ==============================================================================
# Деплой Штурман на Synology NAS
# Домен: vnutrenniy-kompas.ru
# Локальный IP: 192.168.0.72
# Публичный IP: 91.247.233.83
# ==============================================================================

set -e

echo "🚀 Деплой Штурман на Synology"

# --- Проверка окружения ---
if [ -f ".env.prod" ]; then
    echo "📄 Загружаю .env.prod..."
    set -a
    source .env.prod
    set +a
fi

if [ -z "$OPENAI_API_KEY" ]; then
    echo "❌ OPENAI_API_KEY не задан"
    exit 1
fi

if [ -z "$JWT_SECRET" ]; then
    echo "❌ JWT_SECRET не задан"
    exit 1
fi

if [ -z "$DB_PASSWORD" ]; then
    echo "❌ DB_PASSWORD не задан"
    exit 1
fi

if [ -z "$VK_APP_SECRET" ] || [ -z "$VK_WEB_CLIENT_SECRET" ]; then
    echo "❌ VK_APP_SECRET или VK_WEB_CLIENT_SECRET не заданы"
    exit 1
fi

echo "  ✅ Все секреты на месте"

# --- Сборка ---
echo ""
echo "📦 Сборка образов..."
docker compose -f docker-compose.prod.yml build --no-cache

# --- Запуск (сначала БД и Redis) ---
echo ""
echo "▶️  Запуск PostgreSQL и Redis..."
docker compose -f docker-compose.prod.yml up -d postgres redis --wait --wait-timeout 60

# --- Миграции ---
echo ""
echo "🗄️  Запуск миграций Alembic..."
docker compose -f docker-compose.prod.yml exec -T backend \
  sh -c "cd /app && alembic upgrade head" || {
    echo "⚠️  Alembic migration failed — check connection"
    exit 1
}

# --- Запуск остальных сервисов ---
echo ""
echo "▶️  Запуск backend и frontend..."
docker compose -f docker-compose.prod.yml up -d backend frontend --wait --wait-timeout 60

# --- Проверка ---
echo ""
echo "🔍 Проверка..."
sleep 5

# Проверка PostgreSQL
if docker compose -f docker-compose.prod.yml exec -T postgres pg_isready -U shturman > /dev/null 2>&1; then
    echo "  ✅ PostgreSQL — OK"
else
    echo "  ❌ PostgreSQL — не отвечает"
fi

# Проверка Redis
if docker compose -f docker-compose.prod.yml exec -T redis redis-cli ping > /dev/null 2>&1; then
    echo "  ✅ Redis — OK"
else
    echo "  ❌ Redis — не отвечает"
fi

# Проверка бэкенда
sleep 2
if curl -sf -o /dev/null http://localhost:9091/health 2>&1; then
    echo "  ✅ Backend — OK"
else
    echo "  ⚠️  Backend — проверьте логи: docker compose -f docker-compose.prod.yml logs backend"
fi

# Проверка фронтенда
if curl -sf -o /dev/null http://localhost:9090/ 2>&1; then
    echo "  ✅ Frontend — OK"
else
    echo "  ⚠️  Frontend — проверьте логи: docker compose -f docker-compose.prod.yml logs frontend"
fi

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "✨ Штурман развёрнут!"
echo ""
echo "   Локально:  http://192.168.0.72"
echo "   Внешне:    http://91.247.233.83"
echo "   Домен:     http://vnutrenniy-kompas.ru (после DNS)"
echo ""
echo "   API docs:  http://192.168.0.72/api/docs"
echo "   Swagger:   http://192.168.0.72/api/openapi.json"
echo ""
echo "   Логи:      docker compose -f docker-compose.prod.yml logs -f"
echo "   Статус:    docker compose -f docker-compose.prod.yml ps"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"